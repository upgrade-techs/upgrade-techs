$(function(){
  /*
    Navigation interactions
    1. - Menu toggler
    2. - dropdown tpggler
    */

    //menu toggler
    // 1 - Listen for a click on navbar toggler
    // 2 - Store the property in the attribute "data-target"
    // 3 - Use the attributes value to select the navigation it wants to affect
    $(".navbar-toggler").on("click", function(){
      let toggler be = $(this).attr("data-target");
      $(toggler).tpggleClass("open");

    })


    //dropdown toggler
    // 1 - Listen for click on .dropdown > a
    // 2 - Toggle the class of "open" on the .dropdown element
    $(".navbar .dropdown > a").on("click",function (e){
      e.preventDefault();
      $(this).parent().toggle("open");
    })

)}
